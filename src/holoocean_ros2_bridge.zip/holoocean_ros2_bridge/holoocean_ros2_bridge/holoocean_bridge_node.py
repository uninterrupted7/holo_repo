#!/usr/bin/env python3
"""
holoocean_bridge_node.py
========================
HoloOcean v2.3.0 → ROS2 Humble Bridge Node

Runs a SurfaceVessel with ProfilingSonar (multibeam-equivalent) and
publishes all sensor data as standard ROS2 messages.

Published Topics:
  /holoocean/sonar/points          [sensor_msgs/PointCloud2]   - Multibeam sonar 3D points
  /holoocean/sonar/image           [sensor_msgs/Image]         - Raw sonar intensity image
  /holoocean/imu                   [sensor_msgs/Imu]
  /holoocean/gps                   [sensor_msgs/NavSatFix]
  /holoocean/dvl/velocity          [geometry_msgs/TwistStamped]
  /holoocean/odom                  [nav_msgs/Odometry]         - Ground-truth pose
  /holoocean/pose                  [geometry_msgs/PoseStamped] - Ground-truth pose (simple)

Subscribed Topics:
  /holoocean/cmd_vel               [geometry_msgs/Twist]       - Vessel velocity command
"""

import json
import math
import struct
import time

import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy

# ROS2 message types
from builtin_interfaces.msg import Time
from geometry_msgs.msg import (
    PoseStamped, TwistStamped, Twist,
    Point, Quaternion, Vector3, TransformStamped
)
from nav_msgs.msg import Odometry
from sensor_msgs.msg import (
    Imu, NavSatFix, NavSatStatus,
    PointCloud2, PointField, Image
)
from std_msgs.msg import Header, ColorRGBA

from tf2_ros import TransformBroadcaster

import holoocean


def euler_to_quaternion(roll: float, pitch: float, yaw: float) -> Quaternion:
    """Convert Euler angles (radians) to geometry_msgs/Quaternion."""
    cr, sr = math.cos(roll / 2), math.sin(roll / 2)
    cp, sp = math.cos(pitch / 2), math.sin(pitch / 2)
    cy, sy = math.cos(yaw / 2), math.sin(yaw / 2)
    q = Quaternion()
    q.w = cr * cp * cy + sr * sp * sy
    q.x = sr * cp * cy - cr * sp * sy
    q.y = cr * sp * cy + sr * cp * sy
    q.z = cr * cp * sy - sr * sp * cy
    return q


def rotation_matrix_to_quaternion(R: np.ndarray) -> Quaternion:
    """Convert a 3x3 rotation matrix to geometry_msgs/Quaternion."""
    trace = R[0, 0] + R[1, 1] + R[2, 2]
    if trace > 0:
        s = 0.5 / math.sqrt(trace + 1.0)
        w = 0.25 / s
        x = (R[2, 1] - R[1, 2]) * s
        y = (R[0, 2] - R[2, 0]) * s
        z = (R[1, 0] - R[0, 1]) * s
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = 2.0 * math.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2])
        w = (R[2, 1] - R[1, 2]) / s
        x = 0.25 * s
        y = (R[0, 1] + R[1, 0]) / s
        z = (R[0, 2] + R[2, 0]) / s
    elif R[1, 1] > R[2, 2]:
        s = 2.0 * math.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2])
        w = (R[0, 2] - R[2, 0]) / s
        x = (R[0, 1] + R[1, 0]) / s
        y = 0.25 * s
        z = (R[1, 2] + R[2, 1]) / s
    else:
        s = 2.0 * math.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1])
        w = (R[1, 0] - R[0, 1]) / s
        x = (R[0, 2] + R[2, 0]) / s
        y = (R[1, 2] + R[2, 1]) / s
        z = 0.25 * s
    q = Quaternion()
    q.w, q.x, q.y, q.z = w, x, y, z
    return q


def make_header(node: Node, frame_id: str) -> Header:
    """Create a std_msgs/Header with current ROS time."""
    header = Header()
    header.stamp = node.get_clock().now().to_msg()
    header.frame_id = frame_id
    return header


def sonar_to_pointcloud2(
    intensities: np.ndarray,
    azimuth_deg: float,
    range_min: float,
    range_max: float,
    elevation_deg: float,
    intensity_threshold: float,
    header: Header
) -> PointCloud2:
    """
    Convert ProfilingSonar output to sensor_msgs/PointCloud2.

    The ProfilingSonar returns a 2D array [AzimuthBins x RangeBins] of
    intensity values. We perform peak detection per azimuth beam to find
    the strongest range return, then project that into 3D.

    Coordinate convention (sensor frame):
      - x: forward (along vessel heading)
      - y: starboard (right)
      - z: downward (positive toward seafloor)

    The sonar fans out in the y-z plane (across-track) from the vessel keel.
    """
    n_azimuth, n_range = intensities.shape
    azimuth_rad = math.radians(azimuth_deg)
    elevation_rad = math.radians(elevation_deg)
    range_bins = n_range

    # Beam angle for each azimuth bin (centered fan, e.g. -60° to +60°)
    azimuth_angles = np.linspace(
        -azimuth_rad / 2.0, azimuth_rad / 2.0, n_azimuth
    )

    # Range value for each range bin
    ranges = np.linspace(range_min, range_max, range_bins)

    points = []

    for az_idx in range(n_azimuth):
        beam = intensities[az_idx, :]  # intensity across range bins

        if beam.max() < intensity_threshold:
            continue

        # Peak detection: find the first peak above threshold
        peak_idx = int(np.argmax(beam))
        r = ranges[peak_idx]
        intensity_val = float(beam[peak_idx])

        az = azimuth_angles[az_idx]

        # Project: sonar points downward (z positive = down)
        # y = across-track, z = depth
        x = 0.0                           # along-track (sonar is perpendicular)
        y = r * math.sin(az)              # across-track
        z = r * math.cos(az)              # depth (positive down)

        points.append((x, y, z, intensity_val))

    # Build PointCloud2 message
    fields = [
        PointField(name='x', offset=0,  datatype=PointField.FLOAT32, count=1),
        PointField(name='y', offset=4,  datatype=PointField.FLOAT32, count=1),
        PointField(name='z', offset=8,  datatype=PointField.FLOAT32, count=1),
        PointField(name='intensity', offset=12, datatype=PointField.FLOAT32, count=1),
    ]

    point_step = 16  # 4 × float32
    data = bytearray()
    for (px, py, pz, pi) in points:
        data += struct.pack('ffff', px, py, pz, pi)

    pc2 = PointCloud2()
    pc2.header = header
    pc2.height = 1
    pc2.width = len(points)
    pc2.fields = fields
    pc2.is_bigendian = False
    pc2.point_step = point_step
    pc2.row_step = point_step * len(points)
    pc2.data = bytes(data)
    pc2.is_dense = True
    return pc2


def sonar_intensities_to_image(intensities: np.ndarray, header: Header) -> Image:
    """
    Convert ProfilingSonar raw 2D intensity array to sensor_msgs/Image (mono8).
    Useful for visualisation in RViz2 as a 'sonar view'.
    """
    # Normalise to 0-255
    norm = intensities.astype(np.float32)
    if norm.max() > 0:
        norm = (norm / norm.max() * 255.0).astype(np.uint8)
    else:
        norm = np.zeros_like(norm, dtype=np.uint8)

    img = Image()
    img.header = header
    img.height = int(intensities.shape[0])
    img.width = int(intensities.shape[1])
    img.encoding = 'mono8'
    img.is_bigendian = 0
    img.step = img.width
    img.data = norm.flatten().tobytes()
    return img


class HoloOceanBridgeNode(Node):
    """
    ROS2 Node that runs HoloOcean simulation and bridges all sensor
    data to standard ROS2 message types.
    """

    def __init__(self):
        super().__init__('holoocean_bridge')

        # ── Parameters ────────────────────────────────────────────────────
        self.declare_parameter('scenario_file', '')
        self.declare_parameter('scenario_name', 'SurfaceVessel-Mapping')
        self.declare_parameter('use_scenario_file', True)
        self.declare_parameter('world_frame', 'world')
        self.declare_parameter('vessel_frame', 'base_link')
        self.declare_parameter('sonar_frame', 'sonar_link')
        self.declare_parameter('imu_frame', 'imu_link')
        self.declare_parameter('gps_frame', 'gps_link')
        self.declare_parameter('lat_origin', 0.0)
        self.declare_parameter('lon_origin', 0.0)
        self.declare_parameter('sonar_intensity_threshold', 0.1)
        # Sonar configuration (must match scenario)
        self.declare_parameter('sonar_azimuth_deg', 120.0)
        self.declare_parameter('sonar_elevation_deg', 1.0)
        self.declare_parameter('sonar_range_min', 0.5)
        self.declare_parameter('sonar_range_max', 50.0)
        # Vessel command scaling
        self.declare_parameter('thrust_scale', 50.0)

        scenario_file = self.get_parameter('scenario_file').value
        use_file      = self.get_parameter('use_scenario_file').value
        scenario_name = self.get_parameter('scenario_name').value

        self.world_frame  = self.get_parameter('world_frame').value
        self.vessel_frame = self.get_parameter('vessel_frame').value
        self.sonar_frame  = self.get_parameter('sonar_frame').value
        self.imu_frame    = self.get_parameter('imu_frame').value
        self.gps_frame    = self.get_parameter('gps_frame').value
        self.lat_origin   = self.get_parameter('lat_origin').value
        self.lon_origin   = self.get_parameter('lon_origin').value
        self.intensity_th = self.get_parameter('sonar_intensity_threshold').value
        self.azimuth_deg  = self.get_parameter('sonar_azimuth_deg').value
        self.elevation_deg= self.get_parameter('sonar_elevation_deg').value
        self.range_min    = self.get_parameter('sonar_range_min').value
        self.range_max    = self.get_parameter('sonar_range_max').value
        self.thrust_scale = self.get_parameter('thrust_scale').value

        # ── HoloOcean Environment ──────────────────────────────────────────
        self.get_logger().info('Initialising HoloOcean environment...')
        try:
            if use_file and scenario_file:
                with open(scenario_file, 'r') as f:
                    scenario_cfg = json.load(f)
                self.env = holoocean.make(scenario_cfg=scenario_cfg)
            else:
                self.env = holoocean.make(scenario_name)
            self.get_logger().info('HoloOcean environment ready.')
        except Exception as e:
            self.get_logger().error(f'Failed to create HoloOcean env: {e}')
            raise

        # ── Command state ──────────────────────────────────────────────────
        # SurfaceVessel control scheme 0: [left_thrust, right_thrust]
        self._command = np.array([0.0, 0.0])

        # ── QoS ───────────────────────────────────────────────────────────
        sensor_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )

        # ── Publishers ────────────────────────────────────────────────────
        self.pub_sonar_pc2   = self.create_publisher(PointCloud2,    '/holoocean/sonar/points',   sensor_qos)
        self.pub_sonar_img   = self.create_publisher(Image,          '/holoocean/sonar/image',    sensor_qos)
        self.pub_imu         = self.create_publisher(Imu,            '/holoocean/imu',            sensor_qos)
        self.pub_gps         = self.create_publisher(NavSatFix,      '/holoocean/gps',            sensor_qos)
        self.pub_dvl         = self.create_publisher(TwistStamped,   '/holoocean/dvl/velocity',   sensor_qos)
        self.pub_odom        = self.create_publisher(Odometry,       '/holoocean/odom',           10)
        self.pub_pose        = self.create_publisher(PoseStamped,    '/holoocean/pose',           10)

        # ── Subscriber ────────────────────────────────────────────────────
        self.sub_cmd = self.create_subscription(
            Twist,
            '/holoocean/cmd_vel',
            self._cmd_vel_callback,
            10
        )

        # ── TF Broadcaster ────────────────────────────────────────────────
        self.tf_broadcaster = TransformBroadcaster(self)

        # ── Simulation loop timer (runs at ~30 Hz) ─────────────────────
        self._timer = self.create_timer(0.033, self._sim_step)

        self.get_logger().info(
            'HoloOcean ROS2 Bridge started.\n'
            f'  Sonar  → /holoocean/sonar/points  (sensor_msgs/PointCloud2)\n'
            f'  IMU    → /holoocean/imu            (sensor_msgs/Imu)\n'
            f'  GPS    → /holoocean/gps            (sensor_msgs/NavSatFix)\n'
            f'  DVL    → /holoocean/dvl/velocity   (geometry_msgs/TwistStamped)\n'
            f'  Odom   → /holoocean/odom           (nav_msgs/Odometry)\n'
            f'  CmdVel ← /holoocean/cmd_vel        (geometry_msgs/Twist)\n'
        )

    # ──────────────────────────────────────────────────────────────────────
    # Callbacks
    # ──────────────────────────────────────────────────────────────────────

    def _cmd_vel_callback(self, msg: Twist):
        """
        Convert Twist to SurfaceVessel differential-thrust command.
        cmd_vel.linear.x  → forward thrust
        cmd_vel.angular.z → differential yaw torque
        """
        fwd  = msg.linear.x  * self.thrust_scale
        turn = msg.angular.z * self.thrust_scale * 0.5

        left  = np.clip(fwd + turn, -self.thrust_scale, self.thrust_scale)
        right = np.clip(fwd - turn, -self.thrust_scale, self.thrust_scale)
        self._command = np.array([left, right])

    def _sim_step(self):
        """Main simulation tick – step HoloOcean and publish sensor data."""
        try:
            state = self.env.step(self._command)
        except Exception as e:
            self.get_logger().warn(f'HoloOcean step failed: {e}')
            return

        now = self.get_clock().now().to_msg()

        # Publish each sensor if present in this state tick
        if 'ProfilingSonar' in state:
            self._publish_sonar(state['ProfilingSonar'], now)

        if 'IMUSensor' in state:
            self._publish_imu(state['IMUSensor'], now)

        if 'GPSSensor' in state:
            self._publish_gps(state['GPSSensor'], now)

        if 'DVLSensor' in state:
            self._publish_dvl(state['DVLSensor'], now)

        if 'PoseSensor' in state:
            self._publish_pose(state['PoseSensor'], now)

    # ──────────────────────────────────────────────────────────────────────
    # Sensor publishers
    # ──────────────────────────────────────────────────────────────────────

    def _publish_sonar(self, data: np.ndarray, stamp: Time):
        """
        ProfilingSonar → PointCloud2 + Image

        data shape: (AzimuthBins, RangeBins) float array of intensities
        """
        header = Header()
        header.stamp = stamp
        header.frame_id = self.sonar_frame

        # PointCloud2
        pc2 = sonar_to_pointcloud2(
            intensities=data,
            azimuth_deg=self.azimuth_deg,
            range_min=self.range_min,
            range_max=self.range_max,
            elevation_deg=self.elevation_deg,
            intensity_threshold=self.intensity_th,
            header=header
        )
        self.pub_sonar_pc2.publish(pc2)

        # Raw intensity image (sonar view)
        img = sonar_intensities_to_image(data, header)
        self.pub_sonar_img.publish(img)

    def _publish_imu(self, data: np.ndarray, stamp: Time):
        """
        IMUSensor output:
          data[0:3]  → linear acceleration (m/s²) in body frame
          data[3:6]  → angular velocity (rad/s) in body frame
        """
        msg = Imu()
        msg.header.stamp = stamp
        msg.header.frame_id = self.imu_frame

        # Linear acceleration
        msg.linear_acceleration.x = float(data[0])
        msg.linear_acceleration.y = float(data[1])
        msg.linear_acceleration.z = float(data[2])

        # Angular velocity
        msg.angular_velocity.x = float(data[3])
        msg.angular_velocity.y = float(data[4])
        msg.angular_velocity.z = float(data[5])

        # Orientation unknown from IMU alone — mark covariance as -1
        msg.orientation_covariance[0] = -1.0

        # Covariance (diagonal, approximate)
        accel_var = 0.00277 ** 2
        gyro_var  = 0.00123 ** 2
        msg.linear_acceleration_covariance  = [
            accel_var, 0, 0,
            0, accel_var, 0,
            0, 0, accel_var
        ]
        msg.angular_velocity_covariance = [
            gyro_var, 0, 0,
            0, gyro_var, 0,
            0, 0, gyro_var
        ]

        self.pub_imu.publish(msg)

    def _publish_gps(self, data: np.ndarray, stamp: Time):
        """
        GPSSensor output:
          data[0] → latitude  (degrees)
          data[1] → longitude (degrees)
          data[2] → altitude  (meters)  [if depth=false, this is z offset]
        """
        msg = NavSatFix()
        msg.header.stamp = stamp
        msg.header.frame_id = self.gps_frame

        msg.status.status  = NavSatStatus.STATUS_FIX
        msg.status.service = NavSatStatus.SERVICE_GPS

        msg.latitude  = float(data[0]) + self.lat_origin
        msg.longitude = float(data[1]) + self.lon_origin
        msg.altitude  = float(data[2])

        # Position covariance: diagonal, sigma ≈ 0.5 m → variance = 0.25
        pos_var = 0.5 ** 2
        msg.position_covariance = [
            pos_var, 0, 0,
            0, pos_var, 0,
            0, 0, pos_var
        ]
        msg.position_covariance_type = NavSatFix.COVARIANCE_TYPE_DIAGONAL_KNOWN
        self.pub_gps.publish(msg)

    def _publish_dvl(self, data: np.ndarray, stamp: Time):
        """
        DVLSensor output:
          data[0:3] → velocity [vx, vy, vz] in body frame (m/s)
        """
        msg = TwistStamped()
        msg.header.stamp = stamp
        msg.header.frame_id = self.vessel_frame

        msg.twist.linear.x = float(data[0])
        msg.twist.linear.y = float(data[1])
        msg.twist.linear.z = float(data[2])

        self.pub_dvl.publish(msg)

    def _publish_pose(self, data: np.ndarray, stamp: Time):
        """
        PoseSensor output:
          data → 4×4 transformation matrix (position + orientation) in world frame

        Publishes:
          - PoseStamped on /holoocean/pose
          - Odometry on /holoocean/odom
          - TF transform world → base_link
        """
        # Extract position and rotation from 4x4 matrix
        T = data  # shape (4,4)
        pos = T[0:3, 3]   # [x, y, z]
        R   = T[0:3, 0:3] # rotation matrix

        q = rotation_matrix_to_quaternion(R)

        # PoseStamped
        pose_msg = PoseStamped()
        pose_msg.header.stamp = stamp
        pose_msg.header.frame_id = self.world_frame
        pose_msg.pose.position.x  = float(pos[0])
        pose_msg.pose.position.y  = float(pos[1])
        pose_msg.pose.position.z  = float(pos[2])
        pose_msg.pose.orientation = q
        self.pub_pose.publish(pose_msg)

        # Odometry
        odom = Odometry()
        odom.header.stamp    = stamp
        odom.header.frame_id = self.world_frame
        odom.child_frame_id  = self.vessel_frame
        odom.pose.pose.position.x  = float(pos[0])
        odom.pose.pose.position.y  = float(pos[1])
        odom.pose.pose.position.z  = float(pos[2])
        odom.pose.pose.orientation = q
        self.pub_odom.publish(odom)

        # TF: world → base_link
        tf = TransformStamped()
        tf.header.stamp = stamp
        tf.header.frame_id  = self.world_frame
        tf.child_frame_id   = self.vessel_frame
        tf.transform.translation.x = float(pos[0])
        tf.transform.translation.y = float(pos[1])
        tf.transform.translation.z = float(pos[2])
        tf.transform.rotation = q
        self.tf_broadcaster.sendTransform(tf)

        # Static-ish TF: base_link → sonar_link
        # (Sonar is mounted below hull, pointing downward)
        tf_sonar = TransformStamped()
        tf_sonar.header.stamp = stamp
        tf_sonar.header.frame_id = self.vessel_frame
        tf_sonar.child_frame_id  = self.sonar_frame
        tf_sonar.transform.translation.x = 0.0
        tf_sonar.transform.translation.y = 0.0
        tf_sonar.transform.translation.z = -0.3   # 30 cm below keel
        # Sonar points downward: rotate 90° around X
        tf_sonar.transform.rotation = euler_to_quaternion(
            math.pi / 2, 0.0, 0.0
        )
        self.tf_broadcaster.sendTransform(tf_sonar)

    def destroy_node(self):
        """Cleanly close HoloOcean on shutdown."""
        self.get_logger().info('Closing HoloOcean environment...')
        try:
            self.env.close()
        except Exception:
            pass
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = HoloOceanBridgeNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
