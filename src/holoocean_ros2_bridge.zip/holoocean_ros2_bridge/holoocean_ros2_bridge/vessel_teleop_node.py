#!/usr/bin/env python3
"""
vessel_teleop_node.py
=====================
Simple keyboard teleoperation node for the HoloOcean SurfaceVessel.

Publishes geometry_msgs/Twist to /holoocean/cmd_vel

Controls:
  w / s  → increase / decrease forward speed
  a / d  → turn left / right
  SPACE  → emergency stop
  q      → quit
"""

import sys
import tty
import termios
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

HELP = """
HoloOcean Surface Vessel Teleop
────────────────────────────────
  w      forward
  s      backward
  a      turn left
  d      turn right
  SPACE  stop
  q      quit
────────────────────────────────
"""

KEY_BINDINGS = {
    'w': ( 1.0,  0.0),
    's': (-1.0,  0.0),
    'a': ( 0.0,  1.0),
    'd': ( 0.0, -1.0),
    ' ': ( 0.0,  0.0),
}


def get_key(settings):
    tty.setraw(sys.stdin.fileno())
    key = sys.stdin.read(1)
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key


class VesselTeleopNode(Node):
    def __init__(self):
        super().__init__('vessel_teleop')
        self.declare_parameter('linear_scale',  1.0)
        self.declare_parameter('angular_scale', 1.0)
        self._linear  = self.get_parameter('linear_scale').value
        self._angular = self.get_parameter('angular_scale').value
        self._pub = self.create_publisher(Twist, '/holoocean/cmd_vel', 10)
        print(HELP)

    def run(self):
        settings = termios.tcgetattr(sys.stdin)
        try:
            while rclpy.ok():
                key = get_key(settings)
                if key == 'q':
                    break
                if key in KEY_BINDINGS:
                    lin, ang = KEY_BINDINGS[key]
                    msg = Twist()
                    msg.linear.x  = lin * self._linear
                    msg.angular.z = ang * self._angular
                    self._pub.publish(msg)
                    self.get_logger().info(
                        f'CMD → linear.x={msg.linear.x:.2f}  angular.z={msg.angular.z:.2f}'
                    )
        finally:
            # Send stop on exit
            self._pub.publish(Twist())
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)


def main(args=None):
    rclpy.init(args=args)
    node = VesselTeleopNode()
    node.run()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
